1:
librarii: 
opencv-python=>4.6.0.66
numpy=>1.21.5

2:
Task1:

task1.py

run: scrie_rezultate_task1(folder1, folder2), unde folder1
este folderul unde vor fi scrise fisierele .txt continand rezultatele (asezarea pieselor)
iar folder2 este folderul care contine imaginile pentru testare


pentru faza 2, pentru primul task,
rezultatele obtinute pe fisierele de test se afla in folderul 344_Polifronie_Dragos_solutii_task1